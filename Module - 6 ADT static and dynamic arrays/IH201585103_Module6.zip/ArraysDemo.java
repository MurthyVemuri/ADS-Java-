import java.util.*;

class ArraysConcept {

	private int[] values;
	private int size;
	private int curIndex;
	public ArraysConcept(int arraySize) {
		size = arraySize;
		curIndex = -1;
		values = new int[size];
	}

	public void addValue(int arrayValue) {
		if(curIndex % 2 == 0) {
			growArray();
		}
		curIndex++;
		values[curIndex] = arrayValue;
	}

	public void removeValue(int value) {
		for (curIndex = 0; curIndex < values.length; curIndex++) {
			if (value == values[curIndex]) {
				break;
			}
		}
		if(curIndex == values.length) {
			System.out.println("Element not found");
		}else {
			while(curIndex < values.length - 1) {
				values[curIndex] = values[curIndex + 1];
				curIndex++;
			}
		}
	}

	private void growArray() {
		int[] t = new int[values.length * 2];
		System.arraycopy(values , 0 , t , 0 , values.length);
		values = t;

	}

	public void printValues() {
		System.out.println("Elements in the array: ");
		for (int i = 0; i < curIndex + 1; ++i) {
			System.out.print(values[i] + " ");
		}
	}
}

public class ArraysDemo {
	public static void main(String[] args) {
		ArraysConcept<Integer> ac = new ArraysConcept<Integer>(4);
		ArraysConcept<Float> acf = new ArraysConcept<Float>(4);
		ArraysConcept<String> acs = new ArraysConcept<String>(4);
		Scanner scan = new Scanner(System.in);
		String record = scan.nextLine();
		if(record.equals("I")) {
			while(true) {
				String function = scan.next();
				if(function.equals("add")){
					int num = scan.nextInt();
					ac.addValue(num);
				}else if(function.equals("removeElement")) {
					int num = scan.nextInt();
					ac.removeValue(num);
				}else if(function.equals("read")) {
					int num = scan.nextInt();
					ac.getValue(num);
				}else if(function.equals("modifyIndex")) {
					int num = scan.nextInt();
					int num2 = scan.nextInt();
					ac.modify(num,num2);
				}else if(function.equals("modifyElement")) {
					int num = scan.nextInt();
					int num2 = scan.nextInt();
					ac.modifyValue(num,num2);
				}else if(function.equals("print")) {
					ac.printValues();
				}else if(function.equals("end")) {
					break;
				}
			}
		} else if(record.equals("F")) {
			while(true) {
				String function = scan.next();
				if(function.equals("add")){
					float numf = scan.nextFloat();
					acf.addValue(numf);
				}else if(function.equals("removeElement")) {
					float numf = scan.nextFloat();
					acf.removeValue(numf);
				}else if(function.equals("read")) {
					int numf = scan.nextInt();
					acf.getValue(numf);
				}else if(function.equals("modifyIndex")) {
					int num = scan.nextInt();
					float numf2 = scan.nextFloat();
					acf.modify(num,numf2);
				}else if(function.equals("modifyElement")) {
					float num = scan.nextFloat();
					float numf2 = scan.nextFloat();
					acf.modifyValue(num,numf2);
				}else if(function.equals("print")) {
					acf.printValues();
				}else if(function.equals("end")) {
				
				} 
			}
		} else if(record.equals("S") || record.equals("C")) {
			while(true) {
				String function = scan.next();
				if(function.equals("add")){
					String numf = scan.next();
					acs.addValue(numf);
				}else if(function.equals("removeElement")) {
					String numf = scan.next();
					acs.removeValue(numf);
				}else if(function.equals("read")) {
					int numf = scan.nextInt();
					acs.getValue(numf);
				}else if(function.equals("modifyIndex")) {
					int num = scan.nextInt();
					String numf2 = scan.next();
					acs.modify(num,numf2);
				}else if(function.equals("modifyElement")) {
					String num = scan.next();
					String numf2 = scan.next();
					acs.modifyValue(num,numf2);
				}else if(function.equals("print")) {
					acs.printValues();
				}else if(function.equals("end")) {
					break;
				} 
			}
		}
	}
}